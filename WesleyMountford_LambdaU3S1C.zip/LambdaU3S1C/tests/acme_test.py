import unittest
from acme import Product, BoxingGlove
from acme_report import generate_products, ADJ, NOUN

class AcmeProductTests(unittest.TestCase):

    def test_default_product_price(self):
        prod = Product("Test Product")
        self.assertEqual(prod.price, 10)

    def test_legal_names(self):
        prod = generate_products(1)
        names = prod[0].name.split()
        self.assertIn(names[0], ADJ)
        self.assertIn(names[1], NOUN)

    def test_default_num_products(self):
        self.assertEqual(len(generate_products()), 30)

    def test_product_stealability(self):
        low_steal = Product('Worthless', weight=100, price=5)
        self.assertEqual(low_steal.stealability(), "Not so stealable")

        mid_steal = Product('Ehhh... Maybe', weight=80, price=75)
        self.assertEqual(mid_steal.stealability(), "Kinda stealable")

        high_steal = Product('Literally a brick of gold', weight=5, price=75)
        self.assertEqual(high_steal.stealability(), "Very Stealable!")

    def test_product_explosivity(self):
        no_boom = Product("Probably a candle", weight=2, flammability=0.01)
        self.assertEqual(no_boom.explode(), "...fizzle.")

        small_boom = Product("Friendly Neightborhood Pipe Bomb", weight=20, flammability=1)
        self.assertEqual(small_boom.explode(), "...boom!")

        big_badaboom = Product("Actual Nuclear Munitions", weight=100, flammability=2)
        self.assertEqual(big_badaboom.explode(), "...BABOOM!!")

    def test_glove_punch(self):
        tiny_glove = BoxingGlove('Tiny Glove',weight=2)
        self.assertEqual(tiny_glove.punch(),"That tickles.")

        normal_glove = BoxingGlove('Standard Glove')
        self.assertEqual(normal_glove.punch(), "Hey that hurt!")

        giant_glove = BoxingGlove('Standard Glove', weight=5000)
        self.assertEqual(giant_glove.punch(), "OUCH!")

    def test_glove_explosivity(self):
        glove = BoxingGlove('Glove of Explosive Doom')
        self.assertEqual(glove.explode(), "...It's a glove")




if __name__ == '__main__':
    unittest.main()