import random

from acme import Product

ADJ = ['Awesome', 'Shiny', 'Impressive', 'Portable', 'Improved']
NOUN = ['Anvil', 'Catapult', 'Disguise', 'Mousetrap', '???']


def generate_products(number_of_products=30):
    product_list = []


    for prod in range(number_of_products):
        name = f"{random.choice(ADJ)} {random.choice(NOUN)}"
        price = random.randint(5,101)
        weight = random.randint(5, 101)
        flam = random.uniform(0, 2.5)
        product_list.append(Product(name, price=price, weight=weight, flammability=flam))

    return product_list

def inventory_report(products):
    names = []
    price = []
    weight = []
    flam = []
    for prod in products:
        names.append(prod.name)
        price.append(prod.price)
        weight.append(prod.weight)
        flam.append(prod.flammability)

    names = list(set(names))
    #Since we can't import math, we have to calculate means manually.
    total_price = 0
    for i in price:
        total_price += i
    price_mean = total_price/len(price)

    total_weight = 0
    for i in weight:
        total_weight += i
    weight_mean = total_weight / len(weight)

    total_flam = 0
    for i in flam:
        total_flam += i
    flam_mean = total_flam / len(flam)

    print("ACME CORPORATION OFFICIAL INVENTORY REPORT")
    print(f"There are {len(names)} uniquely named products in the inventory. Examples include: {names[0]}, {names[1]}, {names[2]}")
    print(f"Average price: {price_mean}")
    print(f"Average weight: {weight_mean}")
    print(f"Average flammability: {flam_mean}")


if __name__ == '__main__':
    inventory_report(generate_products())