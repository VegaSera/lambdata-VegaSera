from acme import Product, BoxingGlove

prod = Product("A Cool Toy")
print(prod.stealability())
print(prod.explode())

glove = BoxingGlove('Punchy the Third')
print(glove.price)
print(glove.weight)
print(glove.punch())
print(glove.explode)
